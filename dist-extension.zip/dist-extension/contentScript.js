/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
/*!****************************************!*\
  !*** ./src/extension/contentScript.ts ***!
  \****************************************/
__webpack_require__.r(__webpack_exports__);
console.log('Content script loaded');
// Listen for messages from popup
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    console.log('Received message:', message); // Debug log
    if (message.type === 'FILL_CREDENTIALS') {
        var username = message.username, password = message.password;
        console.log('Filling credentials for:', username); // Debug log
        // Try multiple selector patterns
        var passwordFields = document.querySelectorAll('input[type="password"]');
        var usernameFields = document.querySelectorAll('input[type="text"], input[type="email"], input[name="email"], input[name="username"]');
        console.log('Found fields:', {
            usernameFields: usernameFields.length,
            passwordFields: passwordFields.length
        }); // Debug log
        if (usernameFields.length > 0 && passwordFields.length > 0) {
            // Fill username
            var usernameField = usernameFields[0];
            usernameField.value = username;
            usernameField.dispatchEvent(new Event('input', { bubbles: true }));
            usernameField.dispatchEvent(new Event('change', { bubbles: true }));
            // Fill password
            var passwordField = passwordFields[0];
            passwordField.value = password;
            passwordField.dispatchEvent(new Event('input', { bubbles: true }));
            passwordField.dispatchEvent(new Event('change', { bubbles: true }));
            console.log('Credentials filled successfully'); // Debug log
        }
    }
    return true;
});


/******/ })()
;
//# sourceMappingURL=contentScript.js.map